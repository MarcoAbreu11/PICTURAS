class BaseTool:
    pass