var createError = require("http-errors");
var express = require("express");
var cors = require("cors"); // Import cors
var path = require("path");
var cookieParser = require("cookie-parser");
var logger = require("morgan");
var projectsRouter = require("./routes/projects");
var usersRouter = require("./routes/users");
var subscriptionsRouter = require("./routes/subscriptions");
var app = express();

// Enable CORS for all routes
app.use(cors());

// view engine setup
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "jade");

app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

app.use("/projects", projectsRouter);
app.use("/users", usersRouter);
app.use("/subscriptions", subscriptionsRouter);

// catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get("env") === "development" ? err : {};

  // render the error page
  res.status(err.status || 500).jsonp(err);
});

module.exports = app;
